from clickImage import MouseControl
MouseControl.scshot_match(ImagePath = "C:\\Users\\Administrator.SC-201902012149\\Desktop\\template.jpg")
