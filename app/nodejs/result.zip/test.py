from sendiRPA import Browser

Browser.navigateURL(_browser = hWeb, _url = 'about:blank', delayBefore = 1, delayAfter = 1, continue_On_Failure = True)

Browser.click(_browser = hWeb, xpath = , _timeout = 10, delayBefore = 1, delayAfter = 1, continue_On_Failure = True)

Browser.check(_browser = hWeb, xpath = , _timeout = 10, delayBefore = 1, delayAfter = 1, continue_On_Failure = True)

