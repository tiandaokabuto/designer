基本语句块1
基本语句块2
while ( a < 0 ):
  if ( b > 0 ):
    while ( a < 0 ):
  else:
