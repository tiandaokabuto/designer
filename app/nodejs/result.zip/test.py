from sendiRPA import Browser

hWeb = Browser.openBrowser(driverPath = 'C:\\chromedriver\\chromedriver.exe')

