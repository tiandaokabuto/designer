from sendiRPA import Browser

hWeb = Browser.openBrowser(driverPath = 'C:\\chromedriver\\chromedriver.exe', delayBefore = 1, delayAfter = 1, continue_On_Failure = True)

