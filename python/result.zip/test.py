def RPA_356133a8(*argv, **kw):
    from sendiRPA import Browser

    hWeb = Browser.openBrowser(driverPath = "C:\\chromedriver\\chromedriver.exe")

if __name__ == '__main__':
    RPA_356133a8()
