def RPA_b0f6706c(*argv, **kw):

if __name__ == '__main__':
    RPA_b0f6706c()
