
if True:
    print("hhh")
else:
    pass
