def RPA_12():

    print(222)
def RPA_11():

    print(111)
if __name__ == '__main__':

    RPA_11()
    RPA_12()
        