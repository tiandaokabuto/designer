def RPA_59053dde(*argv, **kw):

def RPA_44801f9f(*argv, **kw):

    print(111)
if __name__ == '__main__':
    while True:
        RPA_44801f9f()
        if 2:
            break
    RPA_59053dde()