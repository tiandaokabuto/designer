from time import sleep

sleep( 1 )
print('hhh')